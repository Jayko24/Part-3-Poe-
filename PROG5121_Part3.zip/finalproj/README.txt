PROG5121 PROGRAMMING 1A - PART 3
Store Data and Display Task Report (100 marks)

PROJECT CONTENTS
- Login.java: registration and login functionality reused from the earlier part.
- Message.java: message details, ID, hash and recipient validation.
- StoredMessageManager.java: sent/disregarded/stored arrays, ID/hash arrays, searches, deletion, JSON storage and report.
- QuickChat.java: main application menu and the fourth Stored Messages menu option.
- MessageTest.java: automated tests for Message functionality.
- StoredMessageManagerTest.java: Part 3 tests using the five records supplied in the assignment.
- .github/workflows/testJava.yml: GitHub Actions workflow.
- pom.xml: Maven build configuration (Java 17, Gson and JUnit 5).

OPEN AND TEST IN NETBEANS
1. Extract the ZIP file.
2. In NetBeans select File > Open Project and choose the finalproj folder.
3. Allow Maven to download dependencies (an internet connection is needed the first time).
4. Right-click the project and select Test. Confirm that all tests pass.
5. Run QuickChat.java and test registration, login, sending, storing, disregarding, searching, deletion and the report.
6. Store a message and confirm that messages.json is created in the project working directory.

GITHUB
1. Create or open your own GitHub repository.
2. Upload the complete finalproj folder, including the hidden .github/workflows/testJava.yml file.
3. Commit and push the project.
4. Open the Actions tab and confirm that Java Unit Tests completes successfully.
5. Capture your own screenshots of NetBeans test results and the successful GitHub Actions run for your POE evidence.

IMPORTANT
The five supplied test records are loaded by the JUnit tests to check the required arrays and operations. The application itself accepts messages through its menus and does not silently preload the sample records. Do not state that tests passed until you have run them in NetBeans or GitHub Actions. Screenshots must be genuine screenshots from your own environment.
