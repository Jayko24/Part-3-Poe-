import static org.junit.jupiter.api.Assertions.assertEquals;

import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;

/** Part 3 unit tests using the five records supplied in the assignment. */
class StoredMessageManagerTest {

    private StoredMessageManager createTestManager() {
        StoredMessageManager manager = new StoredMessageManager();
        manager.addMessage(new Message(1, "Jaydiane", "+27834557896",
                "Did you get the cake?", "Sent"));
        manager.addMessage(new Message(2, "Jaydiane", "+27838884567",
                "Where are you? You are late! I have asked you to be on time.", "Stored"));
        manager.addMessage(new Message(3, "Jaydiane", "+27834484567",
                "Yoooooo, I am at your gate.", "Disregard"));
        manager.addMessage(new Message(4, "Developer", "0838884567",
                "It is dinner time !", "Sent"));
        manager.addMessage(new Message(5, "Jaydiane", "+27838884567",
                "Ok, I am leaving without you.", "Stored"));
        return manager;
    }

    @Test
    void sentDisregardedAndStoredArraysContainTheExpectedMessages() {
        StoredMessageManager manager = createTestManager();
        assertEquals(2, manager.getSentMessages().length);
        assertEquals("Did you get the cake?", manager.getSentMessages()[0].getMessage());
        assertEquals("It is dinner time !", manager.getSentMessages()[1].getMessage());
        assertEquals(1, manager.getDisregardedMessages().length);
        assertEquals("Yoooooo, I am at your gate.", manager.getDisregardedMessages()[0].getMessage());
        assertEquals(2, manager.getStoredMessages().length);
        assertEquals("Where are you? You are late! I have asked you to be on time.",
                manager.getStoredMessages()[0].getMessage());
        assertEquals("Ok, I am leaving without you.", manager.getStoredMessages()[1].getMessage());
        assertEquals(5, manager.getMessageIDs().length);
        assertEquals(5, manager.getMessageHashes().length);
    }

    @Test
    void displaysTheLongestStoredMessage() {
        StoredMessageManager manager = createTestManager();
        assertEquals("Where are you? You are late! I have asked you to be on time.",
                manager.findLongestStoredMessage().getMessage());
    }

    @Test
    void searchesForMessageIDAndReturnsItsRecipientAndMessage() {
        StoredMessageManager manager = createTestManager();
        Message expected = manager.getStoredMessages()[0];
        Message actual = manager.searchStoredByID(expected.getMessageID());
        assertEquals(expected.getMessageID(), actual.getMessageID());
        assertEquals("+27838884567", actual.getRecipient());
        assertEquals("Where are you? You are late! I have asked you to be on time.",
                actual.getMessage());
        assertEquals(null, manager.searchStoredByID("not-a-real-id"));
    }

    @Test
    void searchesSentAndStoredMessagesForTheSameRecipient() {
        StoredMessageManager manager = createTestManager();
        Message[] results = manager.searchSentOrStoredByRecipient("+27838884567");
        assertEquals(2, results.length);
        assertEquals("Where are you? You are late! I have asked you to be on time.",
                results[0].getMessage());
        assertEquals("Ok, I am leaving without you.", results[1].getMessage());

        Message[] sentResults = manager.searchSentOrStoredByRecipient("+27834557896");
        assertEquals(1, sentResults.length);
        assertEquals("Did you get the cake?", sentResults[0].getMessage());

        Message[] developerResults = manager.searchSentOrStoredByRecipient("0838884567");
        assertEquals(1, developerResults.length);
        assertEquals("It is dinner time !", developerResults[0].getMessage());
    }

    @Test
    void deletesAStoredMessageUsingItsMessageHash() {
        StoredMessageManager manager = createTestManager();
        String messageHash = manager.getStoredMessages()[0].getMessageHash();
        assertEquals("Message: \"Where are you? You are late! I have asked you to be on time.\" successfully deleted.",
                manager.deleteStoredByHashWithResponse(messageHash));
        assertEquals(1, manager.getStoredMessages().length);
        assertEquals("Ok, I am leaving without you.", manager.getStoredMessages()[0].getMessage());
        assertEquals("Message hash not found.", manager.deleteStoredByHashWithResponse(messageHash));
    }

    @Test
    void displaysAReportContainingMessageHashRecipientAndMessageForSentAndStoredMessages() {
        StoredMessageManager manager = createTestManager();
        String report = manager.createMessageReport();
        assertEquals(true, report.startsWith("MESSAGE REPORT\n"));
        assertEquals(true, report.contains("Message Hash: " + manager.getSentMessages()[0].getMessageHash()));
        assertEquals(true, report.contains("Recipient: +27834557896\nMessage: Did you get the cake?"));
        assertEquals(true, report.contains("Recipient: 0838884567\nMessage: It is dinner time !"));
        assertEquals(true, report.contains("Recipient: +27838884567\nMessage: Where are you? You are late! I have asked you to be on time."));
        assertEquals(true, report.contains("Recipient: +27838884567\nMessage: Ok, I am leaving without you."));
    }

    @Test
    void readsTheStoredMessagesFromJsonIntoTheStoredArray() throws Exception {
        StoredMessageManager manager = createTestManager();
        Path jsonFile = Files.createTempFile("quickchat-part3", ".json");
        try {
            manager.saveStoredMessages(jsonFile);
            StoredMessageManager loadedManager = new StoredMessageManager();
            loadedManager.readStoredMessages(jsonFile);
            assertEquals(2, loadedManager.getStoredMessages().length);
            assertEquals("Where are you? You are late! I have asked you to be on time.",
                    loadedManager.getStoredMessages()[0].getMessage());
            assertEquals("Ok, I am leaving without you.",
                    loadedManager.getStoredMessages()[1].getMessage());
            assertEquals(2, loadedManager.getMessageIDs().length);
            assertEquals(2, loadedManager.getMessageHashes().length);
        } finally {
            Files.deleteIfExists(jsonFile);
        }
    }
}
