import java.security.SecureRandom;

/** Represents one message in the QuickChat application. */
public class Message {
    private static final SecureRandom RANDOM = new SecureRandom();

    // These fields are non-final so Gson can restore them when reading JSON.
    private String messageID;
    private int messageNumber;
    private String sender;
    private String recipient;
    private String message;
    private String messageHash;
    private String flag;

    /** No-argument constructor used when a Message is restored from JSON. */
    public Message() {
        this.messageID = "0000000000";
        this.messageNumber = 0;
        this.sender = "";
        this.recipient = "";
        this.message = "";
        this.messageHash = "";
        this.flag = "Stored";
    }

    public Message(int messageNumber, String recipient, String message) {
        this(messageNumber, "Jaydiane", recipient, message, "Sent");
    }

    public Message(int messageNumber, String sender, String recipient,
                   String message, String flag) {
        this.messageNumber = messageNumber;
        this.sender = sender == null ? "" : sender;
        this.recipient = recipient == null ? "" : recipient;
        this.message = message == null ? "" : message;
        this.flag = flag == null ? "Sent" : flag;
        this.messageID = generateMessageID();
        this.messageHash = createMessageHash();
    }

    private String generateMessageID() {
        long value = 1_000_000_000L + RANDOM.nextLong(9_000_000_000L);
        return Long.toString(value);
    }

    public boolean checkMessageID() {
        return messageID != null && messageID.matches("\\d{10}");
    }

    public String checkRecipientCell() {
        return recipient.matches("^\\+[0-9]{8,12}$")
                ? "Cell phone number successfully captured."
                : "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    /** Creates a hash using the first two ID characters, message number and message words. */
    public String createMessageHash() {
        String trimmed = message == null ? "" : message.trim();
        String[] words = trimmed.isEmpty() ? new String[0] : trimmed.split("\\s+");
        String first = words.length == 0 ? "" : words[0].replaceAll("[^A-Za-z0-9]", "");
        String last = words.length == 0 ? "" : words[words.length - 1].replaceAll("[^A-Za-z0-9]", "");
        String idPrefix = messageID == null || messageID.length() < 2 ? "00" : messageID.substring(0, 2);
        return (idPrefix + ":" + messageNumber + ":" + first + last).toUpperCase();
    }

    public String SentMessage() { return "Message ready to send."; }

    public String printMessages() {
        return "Message ID: " + messageID + System.lineSeparator()
                + "Message Hash: " + messageHash + System.lineSeparator()
                + "Sender: " + sender + System.lineSeparator()
                + "Recipient: " + recipient + System.lineSeparator()
                + "Message: " + message + System.lineSeparator()
                + "Flag: " + flag;
    }

    public int returnTotalMessages() { return 1; }
    public String getMessageID() { return messageID; }
    public int getMessageNumber() { return messageNumber; }
    public String getSender() { return sender; }
    public String getRecipient() { return recipient; }
    public String getMessage() { return message; }
    public String getMessageHash() { return messageHash; }
    public String getFlag() { return flag; }
    public void setFlag(String flag) { this.flag = flag; }
}
