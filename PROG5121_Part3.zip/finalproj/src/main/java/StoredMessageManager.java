import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Manages the message arrays, JSON storage, searches, deletion, and reports. */
public class StoredMessageManager {
    private Message[] sentMessages = new Message[0];
    private Message[] disregardedMessages = new Message[0];
    private Message[] storedMessages = new Message[0];
    private String[] messageHashes = new String[0];
    private String[] messageIDs = new String[0];
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    /** Adds a message to its status array and updates the ID and hash arrays. */
    public void addMessage(Message message) {
        if (message == null) throw new IllegalArgumentException("Message cannot be null.");
        String status = message.getFlag().trim().toLowerCase();
        switch (status) {
            case "sent":
                sentMessages = append(sentMessages, message);
                message.setFlag("Sent");
                break;
            case "disregard":
            case "disregarded":
                disregardedMessages = append(disregardedMessages, message);
                message.setFlag("Disregard");
                break;
            case "stored":
                storedMessages = append(storedMessages, message);
                message.setFlag("Stored");
                break;
            default:
                throw new IllegalArgumentException("Unknown message flag: " + message.getFlag());
        }
        rebuildIndexes();
    }

    private Message[] append(Message[] source, Message value) {
        Message[] result = Arrays.copyOf(source, source.length + 1);
        result[source.length] = value;
        return result;
    }

    private void rebuildIndexes() {
        List<String> hashes = new ArrayList<>();
        List<String> ids = new ArrayList<>();
        for (Message[] group : new Message[][]{sentMessages, disregardedMessages, storedMessages}) {
            for (Message item : group) {
                hashes.add(item.getMessageHash());
                ids.add(item.getMessageID());
            }
        }
        messageHashes = hashes.toArray(new String[0]);
        messageIDs = ids.toArray(new String[0]);
    }

    public Message[] getSentMessages() { return Arrays.copyOf(sentMessages, sentMessages.length); }
    public Message[] getDisregardedMessages() { return Arrays.copyOf(disregardedMessages, disregardedMessages.length); }
    public Message[] getStoredMessages() { return Arrays.copyOf(storedMessages, storedMessages.length); }
    public String[] getMessageHashes() { return Arrays.copyOf(messageHashes, messageHashes.length); }
    public String[] getMessageIDs() { return Arrays.copyOf(messageIDs, messageIDs.length); }

    public String displayStoredSendersAndRecipients() {
        if (storedMessages.length == 0) return "There are no stored messages.";
        StringBuilder output = new StringBuilder();
        for (Message item : storedMessages) {
            output.append("Sender: ").append(item.getSender())
                    .append(" | Recipient: ").append(item.getRecipient())
                    .append(System.lineSeparator());
        }
        return output.toString().trim();
    }

    public Message findLongestStoredMessage() {
        Message longest = null;
        for (Message item : storedMessages) {
            if (longest == null || item.getMessage().length() > longest.getMessage().length()) {
                longest = item;
            }
        }
        return longest;
    }

    public Message searchStoredByID(String id) {
        if (id == null) return null;
        for (Message item : storedMessages) {
            if (item.getMessageID().equals(id)) return item;
        }
        return null;
    }

    /** Searches both sent and stored messages for the requested recipient. */
    public Message[] searchSentOrStoredByRecipient(String recipient) {
        List<Message> matches = new ArrayList<>();
        if (recipient == null) return new Message[0];
        for (Message item : sentMessages) {
            if (item.getRecipient().equals(recipient)) matches.add(item);
        }
        for (Message item : storedMessages) {
            if (item.getRecipient().equals(recipient)) matches.add(item);
        }
        return matches.toArray(new Message[0]);
    }

    /** Kept as a simple method name for compatibility with the earlier test file. */
    public Message[] searchStoredByRecipient(String recipient) {
        return searchSentOrStoredByRecipient(recipient);
    }

    /** Removes a stored message by hash and then rebuilds the ID/hash arrays. */
    public String deleteStoredByHashWithResponse(String hash) {
        for (int index = 0; index < storedMessages.length; index++) {
            Message item = storedMessages[index];
            if (item.getMessageHash().equals(hash)) {
                String deletedMessage = item.getMessage();
                storedMessages = removeAt(storedMessages, index);
                rebuildIndexes();
                return "Message: \"" + deletedMessage + "\" successfully deleted.";
            }
        }
        return "Message hash not found.";
    }

    public boolean deleteStoredByHash(String hash) {
        return !deleteStoredByHashWithResponse(hash).equals("Message hash not found.");
    }

    private Message[] removeAt(Message[] source, int index) {
        Message[] result = new Message[source.length - 1];
        System.arraycopy(source, 0, result, 0, index);
        System.arraycopy(source, index + 1, result, index, source.length - index - 1);
        return result;
    }

    public void saveStoredMessages(Path file) throws IOException {
        Path parent = file.toAbsolutePath().getParent();
        if (parent != null) Files.createDirectories(parent);
        Files.writeString(file, gson.toJson(storedMessages));
    }

    /** Reads the JSON array into the stored-message array without losing other statuses. */
    public void readStoredMessages(Path file) throws IOException {
        if (!Files.exists(file)) {
            storedMessages = new Message[0];
            rebuildIndexes();
            return;
        }
        Message[] loaded = gson.fromJson(Files.readString(file), Message[].class);
        storedMessages = loaded == null ? new Message[0] : loaded;
        for (Message item : storedMessages) item.setFlag("Stored");
        rebuildIndexes();
    }

    /** Report includes every sent and stored message with hash, recipient, and message. */
    public String createMessageReport() {
        StringBuilder report = new StringBuilder("MESSAGE REPORT\n");
        report.append("Total sent messages: ").append(sentMessages.length).append('\n');
        for (Message item : sentMessages) appendReportItem(report, item);
        report.append("Total stored messages: ").append(storedMessages.length).append('\n');
        for (Message item : storedMessages) appendReportItem(report, item);
        return report.toString();
    }

    public String createStoredMessageReport() { return createMessageReport(); }

    private void appendReportItem(StringBuilder report, Message item) {
        report.append("Message Hash: ").append(item.getMessageHash()).append('\n')
                .append("Recipient: ").append(item.getRecipient()).append('\n')
                .append("Message: ").append(item.getMessage()).append('\n')
                .append("------------------------------\n");
    }
}
