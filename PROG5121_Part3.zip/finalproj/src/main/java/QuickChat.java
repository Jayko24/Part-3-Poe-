import java.io.IOException;
import java.nio.file.Path;
import java.util.Scanner;

/** Main QuickChat application, including the Part 3 stored-message menu. */
public class QuickChat {
    private static final StoredMessageManager MANAGER = new StoredMessageManager();
    private static final Path JSON_FILE = Path.of("messages.json");
    private static int totalMessagesSent = 0;

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            Login login = new Login();
            System.out.println("===== QuickChat =====");
            System.out.print("Register username: ");
            String username = scanner.nextLine();
            System.out.print("Register password: ");
            String password = scanner.nextLine();
            if (!login.registerUser(username, password)) {
                System.out.println("Registration failed. Check the username and password rules from Part 1.");
                return;
            }
            System.out.print("Login username: ");
            String loginUsername = scanner.nextLine();
            System.out.print("Login password: ");
            String loginPassword = scanner.nextLine();
            if (!login.loginUser(loginUsername, loginPassword)) {
                System.out.println("Login failed. You cannot continue.");
                return;
            }

            try {
                MANAGER.readStoredMessages(JSON_FILE);
            } catch (IOException exception) {
                System.out.println("Could not read stored messages: " + exception.getMessage());
            }

            System.out.println("Welcome to QuickChat, " + username + ".");
            boolean running = true;
            while (running) {
                System.out.println("\n1) Send Messages\n2) Display Sent Messages\n3) Quit\n4) Stored Messages");
                System.out.print("Choose an option: ");
                switch (scanner.nextLine()) {
                    case "1": addMessages(scanner, username); break;
                    case "2": displaySentMessages(); break;
                    case "3": running = false; break;
                    case "4": storedMessagesMenu(scanner); break;
                    default: System.out.println("Invalid option. Choose 1, 2, 3 or 4.");
                }
            }
            System.out.println("Total number of messages sent: " + totalMessagesSent);
        }
    }

    private static void addMessages(Scanner scanner, String sender) {
        int count = readPositiveInteger(scanner, "How many messages would you like to enter? ");
        for (int number = 1; number <= count; number++) {
            System.out.println("\nMessage " + number);
            System.out.print("Enter recipient with international code: ");
            String recipient = scanner.nextLine();
            System.out.print("Enter message (maximum 250 characters): ");
            String text = scanner.nextLine();
            if (text.length() > 250) {
                System.out.println("Message is too long. Please enter it again.");
                number--;
                continue;
            }
            Message message = new Message(number, sender, recipient, text, "Sent");
            if (!message.checkRecipientCell().startsWith("Cell phone number successfully")) {
                System.out.println(message.checkRecipientCell());
                number--;
                continue;
            }
            System.out.println(message.printMessages());
            System.out.println("1) Send\n2) Disregard\n3) Store");
            System.out.print("Choose what to do with this message: ");
            String action = scanner.nextLine();
            if ("1".equals(action)) {
                MANAGER.addMessage(message);
                totalMessagesSent++;
                System.out.println("Message successfully sent.");
            } else if ("2".equals(action)) {
                message.setFlag("Disregard");
                MANAGER.addMessage(message);
                System.out.println("Message disregarded.");
            } else if ("3".equals(action)) {
                message.setFlag("Stored");
                MANAGER.addMessage(message);
                saveStoredMessages();
                System.out.println("Message successfully stored.");
            } else {
                System.out.println("Invalid option. Please enter 1, 2 or 3.");
                number--;
            }
        }
    }

    private static int readPositiveInteger(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                int value = Integer.parseInt(scanner.nextLine());
                if (value > 0) return value;
            } catch (NumberFormatException ignored) {
                // The user is prompted again when the input is not numeric.
            }
            System.out.println("Enter a positive whole number.");
        }
    }

    private static void displaySentMessages() {
        Message[] sent = MANAGER.getSentMessages();
        if (sent.length == 0) System.out.println("There are no sent messages.");
        for (Message message : sent) System.out.println(message.printMessages() + "\n");
    }

    private static void storedMessagesMenu(Scanner scanner) {
        boolean inMenu = true;
        while (inMenu) {
            System.out.println("\nSTORED MESSAGES\n"
                    + "1) Display sender and recipient of all stored messages\n"
                    + "2) Display the longest stored message\n"
                    + "3) Search for a stored message using Message ID\n"
                    + "4) Search sent and stored messages by recipient\n"
                    + "5) Delete a stored message using Message Hash\n"
                    + "6) Display Message Report\n"
                    + "7) Return to main menu");
            System.out.print("Choose an option: ");
            switch (scanner.nextLine()) {
                case "1":
                    System.out.println(MANAGER.displayStoredSendersAndRecipients());
                    break;
                case "2":
                    Message longest = MANAGER.findLongestStoredMessage();
                    System.out.println(longest == null ? "There are no stored messages." : longest.getMessage());
                    break;
                case "3":
                    System.out.print("Enter Message ID: ");
                    Message found = MANAGER.searchStoredByID(scanner.nextLine());
                    System.out.println(found == null ? "Message not found."
                            : "Recipient: " + found.getRecipient() + "\nMessage: " + found.getMessage());
                    break;
                case "4":
                    System.out.print("Enter recipient number: ");
                    Message[] matches = MANAGER.searchSentOrStoredByRecipient(scanner.nextLine());
                    if (matches.length == 0) System.out.println("No messages found for that recipient.");
                    for (Message match : matches) System.out.println(match.printMessages() + "\n");
                    break;
                case "5":
                    System.out.print("Enter Message Hash: ");
                    System.out.println(MANAGER.deleteStoredByHashWithResponse(scanner.nextLine()));
                    saveStoredMessages();
                    break;
                case "6":
                    System.out.println(MANAGER.createMessageReport());
                    break;
                case "7": inMenu = false; break;
                default: System.out.println("Choose a number from 1 to 7.");
            }
        }
    }

    private static void saveStoredMessages() {
        try {
            MANAGER.saveStoredMessages(JSON_FILE);
        } catch (IOException exception) {
            System.out.println("Could not save JSON file: " + exception.getMessage());
        }
    }

    public static String SentMessage(Message message, String option) {
        if ("1".equals(option)) return "Message successfully sent.";
        if ("2".equals(option)) return "Press 0 to delete the message.";
        if ("3".equals(option)) return "Message successfully stored.";
        return "Invalid message option.";
    }

    public static int returnTotalMessages() { return totalMessagesSent; }
    public static StoredMessageManager getManager() { return MANAGER; }
}
